set path=%PATH%;$G
